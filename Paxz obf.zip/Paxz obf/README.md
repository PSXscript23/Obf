# (PLEASE MAKE YOUR OWN .ENV FILE AND MAKE A VARIABLE NAMED "DISCORD_TOKEN")
# Prometheus Discord Bot (WORKING API)
Original work: https://github.com/prometheus-lua/Prometheus-discord-bot
By: Levno-710

## How to setup?
1. Download this respiratory
2. Extract your files to your desktop or any directory
3. Open ".env" and change the contents in "DISCORD_TOKEN" into your token. (EXAMPLE: DISCORD_TOKEN=230478193478129 <-- fake token)
![Alt text](https://media.discordapp.net/attachments/1072070520922701895/1073468174072283176/image.png "ENV")



4. Run "build.bat" to install all modules
5. Run "Bot.bat" to start your bot.

## Fixing issues
1. If it says no "COLORS" module, just run "FIX.bat" and select 1
2. If it says other problems, run "FIX.bat" and select 2

# BY HUNDREAD (og by levno-710)
